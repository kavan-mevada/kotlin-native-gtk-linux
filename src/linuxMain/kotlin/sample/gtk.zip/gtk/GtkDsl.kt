package sample.gtk.gtk3

@DslMarker
annotation class GtkDsl
